document.addEventListener("DOMContentLoaded", function () {
  const inputText = document.getElementById("inputText");
  const sourceLang = document.getElementById("sourceLang");
  const targetLang = document.getElementById("targetLang");
  const translateBtn = document.getElementById("translateBtn");
  const resultDiv = document.getElementById("result");

  function setResultColor(message, isError = false) {
    resultDiv.textContent = message;
    resultDiv.style.color = isError ? "red" : "green";
  }

  translateBtn.addEventListener("click", function () {
    const text = inputText.value;
    const source = sourceLang.value;
    const target = targetLang.value;

    if (!text) {
      setResultColor("Vui lòng nhập văn bản", true);
      return;
    }

    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: "translate",
        text: text,
        sourceLang: source,
        targetLang: target,
        origin: "popup",
      });
    });

    const apiUrl = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(
      text
    )}&langpair=${source}|${target}`;

    fetch(apiUrl)
      .then((response) => response.json())
      .then((data) => {
        const translatedText = data.responseData.translatedText;

        if (translatedText === "PLEASE SELECT TWO DISTINCT LANGUAGES") {
          setResultColor("VUI LÒNG CHỌN HAI NGÔN NGỮ KHÁC NHAU", true);
        } else if (
          translatedText ===
          "QUERY LENGTH LIMIT EXCEEDED. MAX ALLOWED QUERY : 500 CHARS"
        ) {
          setResultColor("VƯỢT QUÁ GIỚI HẠN SỐ KÝ TỰ (TỐI ĐA 500 KÝ TỰ)", true);
        } else if (data.responseStatus === 200) {
          setResultColor(translatedText);
        } else if (data.responseStatus === 429) {
          const warningMessage = translatedText;
          const timeMatch = warningMessage.match(
            /NEXT AVAILABLE IN\s+(\d+ HOURS? \d+ MINUTES? \d+ SECONDS?)/
          );

          if (timeMatch) {
            const remainingTime = timeMatch[1];
            setResultColor(
              `Đã vượt quá giới hạn. Khả dụng sau: ${remainingTime}`,
              true
            );
          } else {
            setResultColor("Đã vượt quá giới hạn truy cập", true);
          }
        } else {
          setResultColor("Lỗi không xác định", true);
        }
      })
      .catch((error) => {
        setResultColor("Không thể kết nối API", true);
        console.error("Error:", error);
      });
  });

  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.sendMessage(
      tabs[0].id,
      { action: "getSelectedText" },
      function (response) {
        if (response && response.selectedText) {
          inputText.value = response.selectedText;
        }
      }
    );
  });
});
