const supportedLanguages = {
  en: "Tiếng Anh",
  vi: "Tiếng Việt",
  fr: "Tiếng Pháp",
  de: "Tiếng Đức",
  es: "Tiếng Tây Ban Nha",
  zh: "Tiếng Trung",
  ja: "Tiếng Nhật",
  ko: "Tiếng Hàn",
  ru: "Tiếng Nga",
  ar: "Tiếng Ả Rập",
};

function translateSelectedText(
  text,
  sourceLang = "autodetect",
  targetLang = "en",
  origin = "context"
) {
  const apiUrl = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(
    text
  )}&langpair=${sourceLang}|${targetLang}`;

  fetch(apiUrl)
    .then((response) => response.json())
    .then((data) => {
      const translatedText = data.responseData.translatedText;
      let isError = false;
      let errorMessage = translatedText;

      if (translatedText === "PLEASE SELECT TWO DISTINCT LANGUAGES") {
        isError = true;
        errorMessage = "VUI LÒNG CHỌN HAI NGÔN NGỮ KHÁC NHAU";
      } else if (
        translatedText ===
        "QUERY LENGTH LIMIT EXCEEDED. MAX ALLOWED QUERY : 500 CHARS"
      ) {
        isError = true;
        errorMessage = "VƯỢT QUÁ GIỚI HẠN SỐ KÝ TỰ (TỐI ĐA 500 KÝ TỰ)";
      } else if (data.responseStatus === 429) {
        const timeMatch = translatedText.match(
          /NEXT AVAILABLE IN\s+(\d+ HOURS? \d+ MINUTES? \d+ SECONDS?)/
        );
        isError = true;
        errorMessage = timeMatch
          ? `Đã vượt quá giới hạn. Khả dụng sau: ${timeMatch[1]}`
          : "Đã vượt quá giới hạn truy cập";
      } else if (data.responseStatus !== 200) {
        isError = true;
        errorMessage = "Lỗi không xác định";
      }

      if (origin === "context") {
        showContextMenuTranslationPopup(
          text,
          isError ? errorMessage : translatedText,
          targetLang,
          isError
        );
      }
    })
    .catch((error) => {
      if (origin === "context") {
        showContextMenuTranslationPopup(text, "Lỗi kết nối", targetLang);
      }
      console.error("Translation error:", error);
    });
}

function showContextMenuTranslationPopup(
  originalText,
  translatedText,
  currentTargetLang = "en",
  isError = false
) {
  const existingPopup = document.getElementById("context-translation-popup");
  if (existingPopup) {
    existingPopup.remove();
  }

  const popup = document.createElement("div");
  popup.id = "context-translation-popup";
  popup.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background-color: white;
      border: 2px solid #4A90E2;
      border-radius: 10px;
      padding: 20px;
      z-index: 10000;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
      max-width: 600px;
      width: 90%;
      font-family: Arial, sans-serif;
    `;

  const languageOptions = Object.entries(supportedLanguages)
    .map(
      ([code, name]) =>
        `<option value="${code}" ${
          code === currentTargetLang ? "selected" : ""
        }>${name}</option>`
    )
    .join("");

  const isErrorMessage = [
    "PLEASE SELECT TWO DISTINCT LANGUAGES",
    "MAX ALLOWED QUERY : 500 CHARS",
    "Limit reached",
    "Lỗi kết nối",
    "Lỗi gì đó",
  ].some((errorText) => translatedText.includes(errorText));

  popup.innerHTML = `
      <div style="font-weight: bold; margin-bottom: 10px; color: #4A90E2;">MT Translator</div>
      <div style="margin-bottom: 10px;">
        <strong>Ngôn ngữ dịch:</strong>
        <select id="targetLanguageSelect" style="margin-left: 10px; padding: 5px;">
          ${languageOptions}
        </select>
      </div>
      <div style="margin-bottom: 10px;">
        <strong>Gốc:</strong> 
        <span style="color: #666; word-wrap: break-word;">${originalText}</span>
      </div>
      <div>
        <strong>Dịch:</strong> 
        <span style="color: ${
          isError ? "red" : "green"
        }; word-wrap: break-word;" id="translatedTextSpan">${translatedText}</span>
      </div>
      <div style="display: flex; gap: 10px; margin-top: 10px;">
        <button id="translateButton" style="flex-grow: 1; background-color: #4A90E2; color: white; border: none; padding: 10px; border-radius: 5px;">Dịch lại</button>
        <button id="closeContextTranslationPopup" style="flex-grow: 1; background-color: #e74c3c; color: white; border: none; padding: 10px; border-radius: 5px;">Đóng</button>
      </div>
    `;

  document.body.appendChild(popup);

  const closeButton = popup.querySelector("#closeContextTranslationPopup");
  const translateButton = popup.querySelector("#translateButton");
  const languageSelect = popup.querySelector("#targetLanguageSelect");
  const translatedTextSpan = popup.querySelector("#translatedTextSpan");

  closeButton.addEventListener("click", () => {
    popup.remove();
  });

  translateButton.addEventListener("click", () => {
    const newTargetLang = languageSelect.value;
    translateSelectedText(originalText, "autodetect", newTargetLang);
  });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "translate") {
    translateSelectedText(
      request.text,
      request.sourceLang || "autodetect",
      request.targetLang || "en",
      request.origin || "context"
    );
  }

  if (request.action === "getSelectedText") {
    const selectedText = window.getSelection().toString().trim();
    sendResponse({ selectedText: selectedText });
  }
});
