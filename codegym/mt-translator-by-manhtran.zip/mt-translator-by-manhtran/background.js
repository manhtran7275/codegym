chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
      id: "translateSelection",
      title: "MT Translate",
      contexts: ["selection"]
    });
  });
  
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "translateSelection") {
      chrome.tabs.sendMessage(tab.id, {
        action: "translate",
        text: info.selectionText
      });
    }
  });